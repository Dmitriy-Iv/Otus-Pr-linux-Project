-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: wordpress
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (1,2,'_wp_page_template','default'),(2,3,'_wp_page_template','default'),(11,1,'_edit_lock','1637962300:1'),(22,16,'_customize_changeset_uuid','da48833f-637c-4739-a948-9a687f3f467f'),(24,17,'_customize_changeset_uuid','da48833f-637c-4739-a948-9a687f3f467f'),(26,18,'_customize_changeset_uuid','da48833f-637c-4739-a948-9a687f3f467f'),(28,19,'_customize_changeset_uuid','da48833f-637c-4739-a948-9a687f3f467f'),(30,25,'_menu_item_type','custom'),(31,25,'_menu_item_menu_item_parent','0'),(32,25,'_menu_item_object_id','25'),(33,25,'_menu_item_object','custom'),(34,25,'_menu_item_target',''),(35,25,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(36,25,'_menu_item_xfn',''),(37,25,'_menu_item_url','http://wp.lab.local/'),(38,26,'_menu_item_type','post_type'),(39,26,'_menu_item_menu_item_parent','0'),(40,26,'_menu_item_object_id','17'),(41,26,'_menu_item_object','page'),(42,26,'_menu_item_target',''),(43,26,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(44,26,'_menu_item_xfn',''),(45,26,'_menu_item_url',''),(46,27,'_menu_item_type','post_type'),(47,27,'_menu_item_menu_item_parent','0'),(48,27,'_menu_item_object_id','19'),(49,27,'_menu_item_object','page'),(50,27,'_menu_item_target',''),(51,27,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(52,27,'_menu_item_xfn',''),(53,27,'_menu_item_url',''),(54,28,'_menu_item_type','post_type'),(55,28,'_menu_item_menu_item_parent','0'),(56,28,'_menu_item_object_id','18'),(57,28,'_menu_item_object','page'),(58,28,'_menu_item_target',''),(59,28,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(60,28,'_menu_item_xfn',''),(61,28,'_menu_item_url',''),(62,29,'_menu_item_type','custom'),(63,29,'_menu_item_menu_item_parent','0'),(64,29,'_menu_item_object_id','29'),(65,29,'_menu_item_object','custom'),(66,29,'_menu_item_target',''),(67,29,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(68,29,'_menu_item_xfn',''),(69,29,'_menu_item_url','https://www.facebook.com/wordpress'),(70,30,'_menu_item_type','custom'),(71,30,'_menu_item_menu_item_parent','0'),(72,30,'_menu_item_object_id','30'),(73,30,'_menu_item_object','custom'),(74,30,'_menu_item_target',''),(75,30,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(76,30,'_menu_item_xfn',''),(77,30,'_menu_item_url','https://twitter.com/wordpress'),(78,31,'_menu_item_type','custom'),(79,31,'_menu_item_menu_item_parent','0'),(80,31,'_menu_item_object_id','31'),(81,31,'_menu_item_object','custom'),(82,31,'_menu_item_target',''),(83,31,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(84,31,'_menu_item_xfn',''),(85,31,'_menu_item_url','https://www.instagram.com/explore/tags/wordcamp/'),(86,32,'_menu_item_type','custom'),(87,32,'_menu_item_menu_item_parent','0'),(88,32,'_menu_item_object_id','32'),(89,32,'_menu_item_object','custom'),(90,32,'_menu_item_target',''),(91,32,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(92,32,'_menu_item_xfn',''),(93,32,'_menu_item_url','mailto:wordpress@example.com'),(96,33,'_edit_lock','1638225495:1'),(98,36,'_wp_attached_file','2021/11/Car.jpg'),(99,36,'_wp_attachment_metadata','a:5:{s:5:\"width\";i:284;s:6:\"height\";i:177;s:4:\"file\";s:15:\"2021/11/Car.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"Car-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),(102,39,'_wp_attached_file','2021/11/Car2.jpg'),(103,39,'_wp_attachment_metadata','a:5:{s:5:\"width\";i:259;s:6:\"height\";i:194;s:4:\"file\";s:16:\"2021/11/Car2.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"Car2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),(104,40,'_wp_attached_file','2021/11/Car3.jpg'),(105,40,'_wp_attachment_metadata','a:5:{s:5:\"width\";i:275;s:6:\"height\";i:183;s:4:\"file\";s:16:\"2021/11/Car3.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"Car3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),(107,42,'_edit_lock','1638142562:1'),(109,44,'_edit_lock','1638142766:1');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-09 11:24:01
