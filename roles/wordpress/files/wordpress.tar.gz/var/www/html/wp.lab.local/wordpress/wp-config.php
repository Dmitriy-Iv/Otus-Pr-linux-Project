<?php
/**If we got HTTPS from Nginx, we must reply the same way */
if ( $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' )
{
        $_SERVER['HTTPS']       = 'on';
    $_SERVER['SERVER_PORT'] = '443';
        define('FORCE_SSL_ADMIN', true);
}

/**When replying make sure the reply HOST is set to Nginx Rerverse Proxy address, not us */
if ( isset($_SERVER['HTTP_X_FORWARDED_HOST']) )
{
        $_SERVER['HTTP_HOST'] = $_SERVER['HTTP_X_FORWARDED_HOST'];
}
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wpuser' );

/** MySQL database password */
define( 'DB_PASSWORD', 'rRxTh=YdFrwk3' );

/** MySQL hostname */
define( 'DB_HOST', '10.10.62.20' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'z;|}`9&y)|x~ZU1E9cE r51L.WTqNuB(x|}dyMt;_J=Z8%(KczjS$CtdGmMgQ1:r');
define('SECURE_AUTH_KEY',  'JhMm^yS]iV_#GAa2wr(P6]%.DbWC7:;{&l6hW`,u|4,hl]8KN_^dR9K<|FwH4;-p');
define('LOGGED_IN_KEY',    'DM>V|QR^8|H}(P-Wkufj`_>,_`O>(S,6jc$v$:`fxQiR13.?W5_3S=-6W&-|p[%G');
define('NONCE_KEY',        'h5HL2B<$x=)=q8#+UZe6$X<u.X.anXaPg{^iKyKuqXZ|Hsgu.Lcr%[5zX$JMzoe&');
define('AUTH_SALT',        'l%A.T-YppH+ky/*u%-t^[{Zj|[z lN>m{p-=0e{UR@hS}tU{y4*cJV>>}I]7 ,I3');
define('SECURE_AUTH_SALT', 'CTHXhiJCZ8{jS@a!hU.yN;wqwbo|.Oi0D//6h}ijm$CILo]D.Np*M3Op:,5%JuL3');
define('LOGGED_IN_SALT',   'tNmK2}th>:7RuwOw$T!gcJO`uIqF@4k 3wa}d.@1Dx^nr0p@GNF@*|vALvUtb/de');
define('NONCE_SALT',       'v<^u-Sf#0ZwLJ:4oRfYD8Jc~pP8(h=cw|5*wm)HIGTeDiC)3,Aw+g:XkT[k@ 1j^');

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
